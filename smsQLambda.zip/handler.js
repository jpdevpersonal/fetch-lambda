"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const sqsClient = new client_sqs_1.SQSClient({ region: "eu-west-2" });
const QUEUE_URL = "https://sqs.eu-west-2.amazonaws.com/535002890543/RealWorlddemoQueue";
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    for (const record of event.Records) {
        const logMessage = JSON.stringify({
            EventVersion: record.EventVersion,
            EventSubscriptionArn: record.EventSubscriptionArn,
            EventSource: record.EventSource,
            Sns: record.Sns,
        });
        const params = {
            QueueUrl: QUEUE_URL,
            MessageBody: logMessage,
        };
        try {
            const result = yield sqsClient.send(new client_sqs_1.SendMessageCommand(params));
            console.log("Message sent to SQS:", result.MessageId);
        }
        catch (error) {
            console.error("Error sending message to SQS:", error);
            throw error;
        }
    }
});
exports.handler = handler;
